from django.urls import path

from . import views

#Paths related to views.py
urlpatterns = [
    path("", views.index, name = "index"),
    path("login", views.login_view, name = "login"),
    path("logout", views.logout_view, name = "logout"),
    path("register", views.register, name = "register"),
    path("profile/<str:username>", views.profile, name="profile"),
    path('post/new/', views.post_new, name='post_new'),
    path('post/<int:pk>/', views.post_detail, name='post_detail'),
    path('post/<int:pk>/edit/', views.post_edit, name='post_edit'),
    path("add", views.add, name = "add"),
    path("subtract", views.subtract, name = "subtract"),
    path("multiply", views.multiply, name = "multiply"),
    path("divide", views.divide, name = "divide")
]