import json
from django import forms
from django.db import IntegrityError
from django.http import HttpResponse, HttpResponseRedirect, JsonResponse
from django.shortcuts import HttpResponse, HttpResponseRedirect, render, get_object_or_404, redirect
from django.urls import reverse
from django.utils import timezone
from django.shortcuts import redirect
from django.core import serializers
from django.contrib.auth import authenticate, login, logout
from django.forms.models import model_to_dict
from django.contrib.auth.decorators import login_required
from django.core.files.storage import default_storage
from django.views.decorators.csrf import csrf_exempt

from .forms import PostForm
from .models import User, Profile, Blog

# View for main page
def index(request):
    return render(request, "final/index.html")

# View for login page
def login_view(request):
    if request.method == "POST":

        # Attempt to sign user in
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request, username=username, password=password)

        # Check if authentication successful
        if user is not None:
            login(request, user)
            return HttpResponseRedirect(reverse("index"))
        else:
            return render(request, "final/login.html", {
                "message": "Invalid username/password."
            })
    else:
        return render(request, "final/login.html")

# View for after logging out
def logout_view(request):
    logout(request)
    return HttpResponseRedirect(reverse("index"))

# View for register page
def register(request):
    if request.method == "POST":
        username = request.POST["username"]
        email = request.POST["email"]

        #Password match
        password = request.POST["password"]
        confirmation = request.POST["confirmation"]
        if password != confirmation:
            return render(request, "final/register.html", {
                "message": "Passwords don't match."
            })

        #Create new user
        try:
            user = User.objects.create_user(username, email, password)
            user.save()
        except IntegrityError:
            return render(request, "final/register.html", {
                "message": "Username taken.  Please use another one"
            })
        login(request, user)
        return HttpResponseRedirect(reverse("index"))
    else:
        return render(request, "final/register.html")

# View for profile page
def profile(request, username):
    if request.method == 'GET':
        currentuser = request.user
        profileuser = get_object_or_404(User, username = username)

        if request.user.is_anonymous:
            return redirect('login')

    return render(request, "final/profile.html")


def post_new(request):
    if request.method == "POST":
        form = PostForm(request.POST)
        if form.is_valid():
            post = form.save(commit=False)
            post.author = request.user
            post.published_date = timezone.now()
            post.save()
            return redirect('post_detail', pk=post.pk)
    else:
        form = PostForm()

    return render(request, 'final/post_edit.html', {'form': form})

# View for editing post
def post_edit(request, pk):
    post = get_object_or_404(Blog, pk=pk)
    if request.method == "POST":
        form = PostForm(request.POST, instance=post)
        if form.is_valid():
            post = form.save(commit=False)
            post.author = request.user
            post.published_date = timezone.now()
            post.save()
            return redirect('post_detail', pk=post.pk)
    else:
        form = PostForm(instance=post)
    return render(request, 'final/post_edit.html', {'form': form})

# View for post
def post_detail(request, pk):
    post = get_object_or_404(Blog, pk=pk)
    return render(request, 'final/post_detail.html', {'post': post})

# View for addition game
def add(request):
    return render(request, "final/add.html")

# View for subtraction game
def subtract(request):
    return render(request, "final/subtract.html")

# View for multiplication game
def multiply(request):
    return render(request, "final/multiply.html")

# View for division game
def divide(request):
    return render(request, "final/divide.html")


